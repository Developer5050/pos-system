const express = require("express");
const router = express.Router();
const { signup, login, logout } = require("../controllers/authController");
const  authMiddleware   = require("../middlewares/authMiddleware");

// Signup (public)
router.post("/signup", signup);

// Login (public)
router.post("/login", login);

// Logout (protected)
router.post("/logout", authMiddleware, logout);

module.exports = router;
